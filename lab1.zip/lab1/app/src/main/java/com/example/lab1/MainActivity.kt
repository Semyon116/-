package com.example.lab1

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

// Главное окно
class MainActivity : AppCompatActivity() {

    private var totalCalories = 0
    private lateinit var calorieTextView: TextView

    // История продуктов и калорий
    private val productList = mutableListOf<String>()
    private val calorieList = mutableListOf<Int>()

    private val addProductResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val name = result.data?.getStringExtra("product_name") ?: ""
                val calories = result.data?.getIntExtra("calories", 0) ?: 0

                if (name.isNotEmpty()) {
                    // Обновляем калории и добавляем в историю
                    totalCalories += calories
                    calorieTextView.text = getString(R.string.calories_placeholder, totalCalories)
                    productList.add(name)
                    calorieList.add(calories)
                }
            }
        }

    private val addDishResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val dishName = result.data?.getStringExtra("dish_name") ?: ""
                val calories = result.data?.getIntExtra("calories", 0) ?: 0

                if (dishName.isNotEmpty()) {
                    // Обновляем калории и добавляем в историю
                    totalCalories += calories
                    calorieTextView.text = getString(R.string.calories_placeholder, totalCalories)
                    productList.add(dishName)
                    calorieList.add(calories)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        calorieTextView = findViewById(R.id.calorieTextView)
        val addProductButton: Button = findViewById(R.id.addProductButton)
        val addDishButton: Button = findViewById(R.id.addDishButton)
        val historyButton: Button = findViewById(R.id.historyButton) // Кнопка для истории

        addProductButton.setOnClickListener {
            val intent = Intent(this, AddProductActivity::class.java)
            addProductResultLauncher.launch(intent)
        }

        addDishButton.setOnClickListener {
            val intent = Intent(this, AddDishActivity::class.java)
            addDishResultLauncher.launch(intent)
        }

        // Переход в активность истории
        historyButton.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            intent.putStringArrayListExtra("product_list", ArrayList(productList))
            intent.putIntegerArrayListExtra("calorie_list", ArrayList(calorieList))
            startActivity(intent)
        }
    }
}

// Окно добавления продукта
class AddProductActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val caloriesEditText: EditText = findViewById(R.id.caloriesEditText)
        val saveButton: Button = findViewById(R.id.saveButton)

        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val calories = caloriesEditText.text.toString().toIntOrNull() ?: 0
            if (name.isNotEmpty() && calories > 0) {
                val resultIntent = Intent()
                resultIntent.putExtra("product_name", name) // Добавляем имя продукта
                resultIntent.putExtra("calories", calories)
                setResult(RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Введите название и калории", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// Окно добавления блюда
class AddDishActivity : AppCompatActivity() {

    private val dishes = mapOf(
        "Салат" to 150,
        "Пицца" to 300,
        "Суп" to 200,
        "Паста" to 350,
        "Стейк" to 400
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_dish)

        val dishSpinner: Spinner = findViewById(R.id.dishSpinner)
        val saveButton: Button = findViewById(R.id.saveDishButton)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, dishes.keys.toList())
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dishSpinner.adapter = adapter

        saveButton.setOnClickListener {
            val selectedDish = dishSpinner.selectedItem?.toString() ?: ""
            val calories = dishes[selectedDish] ?: 0
            val resultIntent = Intent()
            resultIntent.putExtra("dish_name", selectedDish) // Добавляем имя блюда
            resultIntent.putExtra("calories", calories)
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }
}

// Окно истории
class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        // Получаем данные из Intent
        val productList = intent.getStringArrayListExtra("product_list") ?: arrayListOf()
        val calorieList = intent.getIntegerArrayListExtra("calorie_list") ?: arrayListOf()

        // Создаем список для отображения
        val historyList = ArrayList<String>()
        for (i in productList.indices) {
            historyList.add("${productList[i]} - ${calorieList[i]} калорий")
        }

        // Настроим ListView для отображения данных
        val historyListView: ListView = findViewById(R.id.historyListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, historyList)
        historyListView.adapter = adapter

        // Обработка кнопки "Назад" для возвращения на главный экран
        val backButton: Button = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
    }
}
